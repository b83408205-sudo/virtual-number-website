Virtual Number Website — ابتدائی ورژن

فائلیں:
- app.py: Flask backend
- requirements.txt: Python dependency
- templates/: ویب صفحات

لوکل ٹیسٹ:
1) Python 3 انسٹال کریں
2) pip install -r requirements.txt
3) Linux/macOS:
   export ADMIN_PASSWORD='اپنا-مضبوط-پاس-ورڈ'
   export SECRET_KEY='لمبا-رینڈم-خفیہ-سٹرنگ'
   python app.py
4) /admin/login پر جائیں۔

Render پر:
- New Web Service بنائیں اور اس ZIP کے مواد کو GitHub repository میں رکھیں۔
- Build command: pip install -r requirements.txt
- Start command: gunicorn app:app (اس کے لیے requirements.txt میں gunicorn شامل کریں)
- Environment Variables میں ADMIN_PASSWORD اور SECRET_KEY سیٹ کریں۔
- مستقل ڈیٹا کے لیے persistent disk یا managed database استعمال کریں۔ Render کی عارضی فائل سسٹم پر SQLite/رسیدیں مستقل محفوظ نہیں رہتیں۔
- اپلوڈ فولڈر کو عوامی نہ بنائیں؛ رسیدیں صرف لاگ اِن ایڈمن دیکھ سکے۔

اہم:
یہ ابتدائی starter project ہے، مکمل production-ready ادائیگی کا نظام نہیں۔
JazzCash/Easypaisa ادائیگی خود verify نہیں ہوتی؛ ایڈمن اپنے اکاؤنٹ میں پیمنٹ دیکھ کر ہی منظور کرے۔
اصل فون نمبرز صرف مجاز provider سے حاصل کریں۔ یہ ایپ SMS یا OTP وصول/فارورڈ نہیں کرتی۔
Production میں CSRF protection، rate limiting، database backups، privacy notice اور محفوظ file storage شامل کریں۔
